# Deprecated

from .lalr_interactive_parser import ParserPuppet, ImmutableParserPuppet